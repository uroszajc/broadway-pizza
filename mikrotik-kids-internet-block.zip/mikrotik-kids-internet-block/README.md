# MikroTik Kids Internet Block

Ansible role to schedule kids' internet cutoff on a MikroTik router (RouterOS v7).

---

## What it does

1. Creates an address list of kids device IPs
2. Adds a time-based firewall filter rule that **drops all internet traffic** during defined hours
3. Idempotent — run it again to update IPs or schedule without duplicates

---

## Prerequisites

**On your MikroTik:**

Enable API access (do this once in WinBox or terminal):
```
/ip service/api/enable
/ip service/api/set disabled=no port=8728
```

Or use SSH directly (role falls back to CLI mode automatically).

**On your machine:**
```bash
ansible-galaxy collection install community.routeros
```

---

## Quick Start

1. Copy the example inventory:
```bash
cp inventory.yml.example inventory.yml
```

2. Edit `inventory.yml` with your MikroTik LAN IP and kids device IPs:
```yaml
hosts:
  rt02:
    ansible_host: 192.168.1.1      # your MikroTik IP
    kids_device_ips:
      - 192.168.1.100             # child's phone
      - 192.168.1.101             # child's tablet
    night_start: "22:00"
    night_end: "07:00"
    block_days: "mon,tue,wed,thu,fri"
```

3. Run:
```bash
ansible-playbook -i inventory.yml playbook.yml
```

---

## Config Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `kids_device_ips` | **required** | IPs or CIDRs to block |
| `kids_block_enabled` | `true` | `false` to disable block without deleting rules |
| `night_start` | `"22:00"` | Block start time |
| `night_end` | `"07:00"` | Block end time |
| `block_days` | `"mon,tue,wed,thu,fri"` | Days to apply block |
| `rule_prefix` | `"kids-block"` | Prefix for firewall rules |

### Enable/disable without deleting

Set `kids_block_enabled: false` in your inventory and re-run — the rule gets disabled (not deleted). To re-enable, set back to `true` and run again.

```yaml
# Disable for school holidays, re-enable after
kids_block_enabled: false
```

### Weekend-only config:
```yaml
weekend_block_days: "fri,sat,sun"
# Override with different hours in inventory
```

---

## How it works

MikroTik's `time=` parameter on firewall rules uses **local router time** — so it automatically respects your timezone.

The rule drops TCP/UDP forward traffic FROM the kids' devices during the scheduled window. It does NOT block them from accessing local LAN devices (printers, etc.) — that's intentional so family/local devices stay reachable.

---

## Troubleshooting

**"Connection refused" on port 8728:**
→ Enable API: `/ip service/api/enable`

**Rule not triggering:**
→ Check router clock: `/system/clock/print` — time must be correct and in your local timezone

**Kids bypassing via VPN:**
→ Add additional rules to block the specific VPN ports — they're harder to block at the firewall level since VPN traffic looks like HTTPS

**To manually remove rules:**
```
/ip/firewall/filter/remove [find comment~"kids-block"]
/ip/firewall/address-list/remove [find list="kids-block-devices"]
```